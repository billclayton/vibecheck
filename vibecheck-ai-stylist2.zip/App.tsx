
import { useState, useRef, FC, ChangeEvent, useEffect } from 'react';
import { AppState } from './types';
import { analyzeImage, editImage } from './services/geminiService';
import AnalysisDisplay from './components/AnalysisDisplay';
import VoiceInterface from './components/VoiceInterface';
import DrawingCanvas from './components/DrawingCanvas';

const App: FC = () => {
  const [state, setState] = useState<AppState>({
    image: null,
    analysis: null,
    isAnalyzing: false,
    isEditing: false,
    error: null,
  });

  const [isQuillMode, setIsQuillMode] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 1080 }, height: { ideal: 1440 } } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera Error:", err);
      setState(prev => ({ ...prev, error: "Camera access was denied. Please check permissions." }));
      setIsCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(videoRef.current, 0, 0);
    const base64 = canvas.toDataURL('image/jpeg');
    
    // Stop camera
    const stream = videoRef.current.srcObject as MediaStream;
    stream.getTracks().forEach(track => track.stop());
    setIsCameraActive(false);
    
    processNewImage(base64);
  };

  const processNewImage = async (base64: string) => {
    setState(prev => ({ ...prev, image: base64, analysis: null, error: null, isAnalyzing: true }));
    try {
      const result = await analyzeImage(base64);
      setState(prev => ({ ...prev, analysis: result, isAnalyzing: false }));
    } catch (err: any) {
      setState(prev => ({ ...prev, isAnalyzing: false, error: err.message || "Failed to analyze image." }));
    }
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      processNewImage(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleEdit = async (prompt: string) => {
    if (!state.image) return;
    setIsQuillMode(false);
    setState(prev => ({ ...prev, isEditing: true, error: null, analysis: null }));

    try {
      const newImage = await editImage(state.image, prompt);
      setState(prev => ({ ...prev, image: newImage, isAnalyzing: true, isEditing: false }));
      const newAnalysis = await analyzeImage(newImage);
      setState(prev => ({ ...prev, analysis: newAnalysis, isAnalyzing: false }));
    } catch (err: any) {
      setState(prev => ({ ...prev, isEditing: false, error: err.message || "The style magic failed!" }));
    }
  };

  const clearImage = () => {
    setState({ image: null, analysis: null, isAnalyzing: false, isEditing: false, error: null });
    setIsQuillMode(false);
    setIsCameraActive(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 pb-40">
      <header className="sticky top-0 z-[100] bg-white/70 backdrop-blur-xl border-b border-gray-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100 rotate-3">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-7.714 2.143L11 21l-2.286-6.857L1 12l7.714-2.143L11 3z" /></svg>
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-gray-900 leading-none">VibeCheck</h1>
            <p className="text-[10px] uppercase tracking-widest font-bold text-indigo-500">AI Fashion Critic</p>
          </div>
        </div>
        
        {state.image && !isCameraActive && (
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsQuillMode(!isQuillMode)}
              className={`p-2.5 rounded-2xl transition-all ${isQuillMode ? 'bg-indigo-600 text-white shadow-lg ring-4 ring-indigo-50' : 'bg-gray-100 text-gray-400 hover:text-indigo-600'}`}
              title="Magic Quill Mode"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
            </button>
            <button 
              onClick={clearImage}
              className="p-2.5 bg-gray-100 text-gray-400 rounded-2xl hover:bg-red-50 hover:text-red-500 transition-all"
              title="Start Over"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
            </button>
          </div>
        )}
      </header>

      <main className="max-w-md mx-auto px-6 pt-8">
        {!state.image && !isCameraActive ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-10">
            <div className="relative group">
              <div className="absolute inset-0 bg-indigo-200 rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
              <div className="w-40 h-40 bg-white rounded-full flex items-center justify-center shadow-2xl relative border border-gray-100">
                <svg className="w-20 h-20 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              </div>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-3xl font-black text-gray-900 tracking-tight">Ready for a Vibe Check?</h2>
              <p className="text-gray-500 max-w-[280px] mx-auto text-lg leading-snug font-medium">Capture your fit or upload a photo for brutal visual honesty.</p>
            </div>

            <div className="w-full space-y-4">
              <button 
                onClick={startCamera}
                className="w-full bg-indigo-600 text-white font-bold py-5 rounded-3xl shadow-2xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center space-x-3 text-xl"
              >
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                <span>Snap Outfit</span>
              </button>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full bg-white text-gray-700 border-2 border-gray-100 font-bold py-4 rounded-3xl hover:bg-gray-50 active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                <span>Upload Gallery</span>
              </button>
            </div>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
          </div>
        ) : isCameraActive ? (
          <div className="relative aspect-[3/4] bg-black rounded-[40px] overflow-hidden shadow-2xl ring-8 ring-white">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-x-0 bottom-10 flex flex-col items-center space-y-6">
              <button 
                onClick={capturePhoto}
                className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-xl ring-4 ring-white/30 active:scale-90 transition-all"
              >
                <div className="w-16 h-16 border-4 border-gray-900 rounded-full"></div>
              </button>
              <button onClick={() => setIsCameraActive(false)} className="text-white font-bold text-sm bg-black/40 backdrop-blur-md px-6 py-2 rounded-full border border-white/20">Cancel</button>
            </div>
          </div>
        ) : (
          <div className="space-y-8 pb-10">
            <div className="relative group overflow-hidden rounded-[40px] shadow-2xl bg-white aspect-[3/4] flex items-center justify-center border-8 border-white ring-1 ring-gray-100">
              <img 
                src={state.image!} 
                alt="Your Style" 
                className={`w-full h-full object-cover transition-all duration-700 ${state.isEditing || state.isAnalyzing ? 'opacity-40 grayscale blur-xl scale-110' : 'opacity-100 scale-100'}`} 
              />
              
              <DrawingCanvas 
                isActive={isQuillMode && !state.isEditing && !state.isAnalyzing}
                onComplete={handleEdit}
                onCancel={() => setIsQuillMode(false)}
              />

              {(state.isEditing || state.isAnalyzing) && (
                <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4 z-50">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                       <svg className="w-6 h-6 text-indigo-600 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-7.714 2.143L11 21l-2.286-6.857L1 12l7.714-2.143L11 3z" /></svg>
                    </div>
                  </div>
                  <p className="text-indigo-900 font-bold bg-white/90 px-8 py-3 rounded-2xl shadow-2xl backdrop-blur-md border border-indigo-50">
                    {state.isEditing ? "Spinning new threads..." : "Consulting the fashion gods..."}
                  </p>
                </div>
              )}
            </div>

            {state.error && (
              <div className="bg-red-50 text-red-600 p-5 rounded-3xl border border-red-100 text-sm font-bold animate-in fade-in zoom-in duration-300 shadow-sm">
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  <span>{state.error}</span>
                </div>
              </div>
            )}

            {state.analysis && !state.isAnalyzing && !state.isEditing && (
              <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
                <AnalysisDisplay analysis={state.analysis} />
              </div>
            )}
          </div>
        )}
      </main>

      {state.image && !isCameraActive && (
        <VoiceInterface 
          currentImage={state.image} 
          onCommand={handleEdit} 
        />
      )}
    </div>
  );
};

export default App;
