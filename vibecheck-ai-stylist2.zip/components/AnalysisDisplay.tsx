
import { FC } from 'react';
import { AnalysisResult } from '../types';

interface AnalysisDisplayProps {
  analysis: AnalysisResult;
}

const AnalysisDisplay: FC<AnalysisDisplayProps> = ({ analysis }) => {
  return (
    <div className="space-y-8 pb-32">
      <div className="flex justify-center">
        <div className="relative group">
          <div className="absolute inset-0 bg-indigo-500 blur-xl opacity-20 scale-110"></div>
          <span className="relative bg-black text-white px-6 py-2 rounded-full text-sm font-black tracking-widest uppercase border border-white/20">
            {analysis.archetype}
          </span>
        </div>
      </div>

      <section className="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-5">
          <svg className="w-20 h-20" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21L14.017 18C14.017 16.8954 13.1216 16 12.017 16C10.9124 16 10.017 16.8954 10.017 18L10.017 21H4.01703V12C4.01703 7.58172 7.59875 4 12.017 4C16.4353 4 20.017 7.58172 20.017 12V21H14.017Z" /></svg>
        </div>
        <h3 className="text-xs font-black text-indigo-500 mb-3 tracking-widest uppercase flex items-center">
          <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
          First Impression
        </h3>
        <p className="text-xl font-bold text-gray-900 leading-tight italic">
          "{analysis.firstImpression}"
        </p>
      </section>

      <section className="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100">
        <h3 className="text-xs font-black text-indigo-500 mb-6 tracking-widest uppercase flex items-center">
          <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
          Style Breakdown
        </h3>
        <div className="space-y-4">
          {analysis.breakdown.map((item, idx) => (
            <div key={idx} className="flex items-center space-x-4 group">
              <div className="w-8 h-8 rounded-xl bg-gray-50 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-50 transition-colors">
                {idx + 1}
              </div>
              <span className="text-gray-700 font-medium">{item}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-indigo-600 p-8 rounded-[32px] text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
        <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
        <h3 className="text-xs font-black text-indigo-200 mb-3 tracking-widest uppercase flex items-center">
          <span className="w-2 h-2 bg-indigo-300 rounded-full mr-2"></span>
          The Brutal Honest T
        </h3>
        <p className="text-lg font-bold leading-relaxed">
          {analysis.humor}
        </p>
      </section>

      <section className="space-y-4">
        <h3 className="text-xs font-black text-indigo-500 px-2 tracking-widest uppercase flex items-center">
          <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
          Creative Vibe
        </h3>
        <div className="grid gap-3">
          {analysis.creativeInterpretations.map((item, idx) => (
            <div key={idx} className="p-5 bg-white rounded-2xl border border-gray-100 text-gray-600 text-sm font-semibold italic shadow-sm hover:border-indigo-200 transition-colors">
              {item}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AnalysisDisplay;
