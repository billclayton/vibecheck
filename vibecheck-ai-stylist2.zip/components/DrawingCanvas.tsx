
import { useRef, useState, useEffect, FC, MouseEvent, TouchEvent, FormEvent } from 'react';

interface DrawingCanvasProps {
  onComplete: (prompt: string) => void;
  onCancel: () => void;
  isActive: boolean;
}

const DrawingCanvas: FC<DrawingCanvasProps> = ({ onComplete, onCancel, isActive }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const [promptValue, setPromptValue] = useState('');
  const [lastPos, setLastPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!isActive) {
      const ctx = canvasRef.current?.getContext('2d');
      ctx?.clearRect(0, 0, canvasRef.current?.width || 0, canvasRef.current?.height || 0);
      setShowPrompt(false);
      setPromptValue('');
    }
  }, [isActive]);

  const getPos = (e: MouseEvent | TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? (e as TouchEvent).touches[0].clientX : (e as MouseEvent).clientX;
    const clientY = 'touches' in e ? (e as TouchEvent).touches[0].clientY : (e as MouseEvent).clientY;
    
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e: MouseEvent | TouchEvent) => {
    if (showPrompt) return;
    setIsDrawing(true);
    setLastPos(getPos(e));
  };

  const draw = (e: MouseEvent | TouchEvent) => {
    if (!isDrawing || showPrompt) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    const currentPos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(lastPos.x, lastPos.y);
    ctx.lineTo(currentPos.x, currentPos.y);
    
    // Glowing laser ink effect
    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 45;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#6366f1';
    ctx.globalAlpha = 0.6;
    ctx.stroke();

    setLastPos(currentPos);
  };

  const endDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    setShowPrompt(true);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (promptValue.trim()) {
      onComplete(promptValue);
    }
  };

  if (!isActive) return null;

  return (
    <div className="absolute inset-0 z-20 cursor-crosshair touch-none overflow-hidden rounded-[32px]">
      <canvas
        ref={canvasRef}
        width={800} 
        height={1066}
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={endDrawing}
        onMouseLeave={endDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={endDrawing}
        className="w-full h-full"
      />

      {showPrompt && (
        <div className="absolute inset-0 flex items-center justify-center bg-indigo-900/20 backdrop-blur-md animate-in fade-in duration-300 z-30">
          <form 
            onSubmit={handleSubmit}
            className="bg-white p-8 rounded-[40px] shadow-2xl w-[90%] space-y-6 transform scale-100 border border-indigo-50"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                </div>
                <span className="text-sm font-black text-indigo-600 uppercase tracking-widest">Magic Quill</span>
              </div>
              <button type="button" onClick={() => { setShowPrompt(false); onCancel(); }} className="p-2 text-gray-400 hover:bg-gray-100 rounded-full transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-gray-900">Cast a style spell</h3>
              <p className="text-gray-500 text-sm font-medium">What should happen to the highlighted area?</p>
            </div>

            <div className="relative">
              <input
                autoFocus
                type="text"
                placeholder="e.g. 'Turn into a gold chain'"
                className="w-full bg-gray-50 border-2 border-transparent focus:border-indigo-600 focus:bg-white outline-none p-5 rounded-2xl text-gray-800 font-bold transition-all placeholder:text-gray-400 text-lg"
                value={promptValue}
                onChange={(e) => setPromptValue(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-5 rounded-[24px] font-black text-xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <span>Manifest It</span>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default DrawingCanvas;
