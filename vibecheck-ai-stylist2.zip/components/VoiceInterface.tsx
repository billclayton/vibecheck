
import { useState, useEffect, useRef, FC } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { decodeAudioData, decodeBase64, encodeBase64 } from '../services/geminiService';

interface VoiceInterfaceProps {
  currentImage: string | null;
  onCommand: (command: string) => void;
}

const VoiceInterface: FC<VoiceInterfaceProps> = ({ currentImage, onCommand }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const currentTranscriptionRef = useRef('');

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
    setTranscription('');
    currentTranscriptionRef.current = '';
    
    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();
  };

  const startSession = async () => {
    // 1. CRITICAL: Initialize AudioContext in the SYNC path of the user gesture to avoid "Not Allowed" errors
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    }
    if (!outAudioContextRef.current) {
      outAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }

    // Resume contexts if they were suspended by the browser
    if (audioContextRef.current.state === 'suspended') await audioContextRef.current.resume();
    if (outAudioContextRef.current.state === 'suspended') await outAudioContextRef.current.resume();

    setIsConnecting(true);
    setError(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const blob = {
                data: encodeBase64(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                if (session) session.sendRealtimeInput({ media: blob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outAudioContextRef.current) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outAudioContextRef.current.currentTime);
              const buffer = await decodeAudioData(decodeBase64(base64Audio), outAudioContextRef.current, 24000, 1);
              const source = outAudioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(outAudioContextRef.current.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              currentTranscriptionRef.current += text;
              setTranscription(currentTranscriptionRef.current);
            }

            if (message.serverContent?.turnComplete) {
              const final = currentTranscriptionRef.current.trim().toLowerCase();
              // Keywords that suggest the user wants a visual change
              const editKeywords = ["change", "add", "make", "put", "try", "switch", "give", "wear", "dress", "swap", "remove"];
              const shouldTrigger = editKeywords.some(keyword => final.includes(keyword));
              
              if (shouldTrigger && final.length > 5) {
                onCommand(currentTranscriptionRef.current);
                stopSession();
              } else {
                currentTranscriptionRef.current = '';
                setTranscription('');
              }
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Live API Error:', e);
            setError("The mic check failed. Try again?");
            stopSession();
          },
          onclose: () => {
            stopSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: `You are 'VibeCheck', a sharp-tongued, hilarious, and ultra-high-fashion AI stylist. 
          When the user speaks, you respond like a seasoned fashion director who has seen it all. 
          If they ask for a change, be encouraging but witty: 'Oh honey, that beige needs to GO. Let's try it!' or 'Finally! A choice with some spine! Let me work my magic.'
          CRITICAL: Keep responses under 8 seconds. When you agree to a change, stop speaking immediately so the system can process the edit.`,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          },
          inputAudioTranscription: {},
        }
      });

      sessionRef.current = await sessionPromise;
      
      if (currentImage) {
        sessionRef.current.sendRealtimeInput({
          media: { data: currentImage.split(',')[1], mimeType: 'image/jpeg' }
        });
      }
    } catch (err: any) {
      console.error("Mic Error:", err);
      setError("Permission denied. Check your browser settings!");
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-white via-white/90 to-transparent pointer-events-none z-[60]">
      <div className="max-w-md mx-auto pointer-events-auto">
        <div className={`transition-all duration-300 transform ${isActive || error ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-95 opacity-0'}`}>
          <div className={`p-4 rounded-2xl shadow-xl flex items-center space-x-4 mb-4 border ${error ? 'bg-red-50 border-red-200' : 'bg-indigo-600 border-indigo-400 text-white'}`}>
             <div className="flex-1 overflow-hidden">
                <p className={`text-xs uppercase tracking-widest font-bold mb-1 flex items-center ${error ? 'text-red-600' : 'text-indigo-200'}`}>
                  {error ? (
                    'Error'
                  ) : (
                    <>
                      <span className="w-2 h-2 bg-red-400 rounded-full mr-2 animate-pulse"></span>
                      Live Stylist
                    </>
                  )}
                </p>
                <p className={`truncate text-sm italic ${error ? 'text-red-800' : 'opacity-90'}`}>
                  {error || transcription || "Say something like 'change my jacket to neon pink'..."}
                </p>
             </div>
          </div>
        </div>

        <button
          onClick={isActive ? stopSession : startSession}
          disabled={isConnecting}
          className={`w-full py-5 rounded-2xl flex items-center justify-center space-x-3 shadow-2xl transition-all active:scale-95 ${
            isActive 
              ? 'bg-red-500 text-white animate-pulse shadow-red-200' 
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-300'
          }`}
        >
          {isConnecting ? (
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
          ) : (
            <>
              {isActive ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
              )}
              <span className="font-bold text-lg">{isActive ? 'I am Listening...' : 'Talk to Your Stylist'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default VoiceInterface;
