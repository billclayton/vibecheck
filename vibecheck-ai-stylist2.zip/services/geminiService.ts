
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { AnalysisResult } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeImage = async (base64Image: string): Promise<AnalysisResult> => {
  const ai = getAI();
  const prompt = `You are a world-class fashion stylist and witty social commentator. 
  Analyze this image of a person. Be observant, incredibly insightful, and sharp-tongued but playful (think "loving roast").
  
  Return the analysis in a strictly formatted JSON object with the following keys:
  - firstImpression: A punchy, clever summary of the overall vibe.
  - breakdown: An array of 5 specific visual details (clothes, posture, grooming, accessories).
  - humor: A witty, "Joan Rivers-esque" observation about their style choices.
  - archetype: A hilarious, hyper-specific label (e.g., "The 'I definitely have a bidet' Tech Lead" or "Brooklyn Potter in a Mid-Life Awakening").
  - creativeInterpretations: An array of 3 "Where they're going" or "What their house looks like" guesses based on the vibe.
  
  Do NOT identify the person. Stick to visual style cues only.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image.split(',')[1] || base64Image } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          firstImpression: { type: Type.STRING },
          breakdown: { type: Type.ARRAY, items: { type: Type.STRING } },
          humor: { type: Type.STRING },
          archetype: { type: Type.STRING },
          creativeInterpretations: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['firstImpression', 'breakdown', 'humor', 'archetype', 'creativeInterpretations']
      }
    }
  });

  try {
    const text = response.text;
    return JSON.parse(text || '{}');
  } catch (e) {
    console.error("JSON Parse Error:", e);
    throw new Error("The stylist is speechless (failed to parse results).");
  }
};

export const editImage = async (base64Image: string, editPrompt: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image.split(',')[1] || base64Image } },
        { text: `Edit this person according to: ${editPrompt}. Maintain identity and pose. Change clothing, colors, or accessories as requested.` }
      ]
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("The magic brush ran out of ink (no image returned).");
};

export const decodeBase64 = (base64: string) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

export const encodeBase64 = (bytes: Uint8Array) => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
