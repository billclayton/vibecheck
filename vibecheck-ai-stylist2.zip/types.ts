
export interface AnalysisResult {
  firstImpression: string;
  breakdown: string[];
  humor: string;
  archetype: string;
  creativeInterpretations: string[];
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface AppState {
  image: string | null;
  analysis: AnalysisResult | null;
  isAnalyzing: boolean;
  isEditing: boolean;
  error: string | null;
}
